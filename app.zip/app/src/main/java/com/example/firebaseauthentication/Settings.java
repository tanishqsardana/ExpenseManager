package com.example.firebaseauthentication;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;

public class Settings extends Fragment {

    Button logout_btn;
    FirebaseAuth mAuth;


    public Settings() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View SettingView = inflater.inflate(R.layout.fragment_settings, container, false);
        Button logout_btn = SettingView.findViewById(R.id.logout_btn);
        Button login_btn = SettingView.findViewById(R.id.login_btn);

        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent iLogin = new Intent(getActivity(), Login_Settings.class);
                startActivity(iLogin);
            }
        });


        logout_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mAuth.signOut();
                startActivity(new Intent(getActivity() , LoginActivity.class));
            }
        });

    return(SettingView);
    }
}