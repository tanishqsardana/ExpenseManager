package com.example.firebaseauthentication;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class AddTransaction extends Fragment {


    public AddTransaction() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_add_transaction, container, false);

        Spinner spinner = view.findViewById(R.id.acctype);
        TextView datedisplay = view.findViewById(R.id.date);
        String currentDateTimeString = java.text.DateFormat.getDateTimeInstance().format(new Date());

        datedisplay.setText(currentDateTimeString);

        ArrayList<String> arrIds = new ArrayList<String>();

        arrIds.add("Cash");
        arrIds.add("Paytm");
        arrIds.add("Credit Card");
        arrIds.add("Debit Card");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity().getApplicationContext(),
                android.R.layout.simple_spinner_dropdown_item, arrIds);
        spinner.setAdapter(adapter);

        Spinner spin = view.findViewById(R.id.categories);


        ArrayList<String> arrId = new ArrayList<String>();

        arrId.add("Food and Drink");
        arrId.add("Transport");
        arrId.add("Bills");
        arrId.add("Groceries");

        ArrayAdapter<String> adapt = new ArrayAdapter<String>(getActivity().getApplicationContext(),
                android.R.layout.simple_spinner_dropdown_item, arrId);
        spin.setAdapter(adapt);

        return(view);
    }
}

